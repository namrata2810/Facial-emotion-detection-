# Face_Emotion_Recognition_Machine_Learning
Face Emotion Recognition using Machine Learning Python

Watch Tutorial :- https://www.youtube.com/watch?v=aoCIoumbWQY
